import React from "react";
import "../../image/_sFRRIYIwnk 1.png";
const Article = () => {
  return (
    <div className="Article-url-img">
      <h1 className="Как-h1">Как мы работаем</h1>
      <div className="display-justiful-article">
        <div>
          <h1 className="white-h1">1</h1>
          <p className="white-p">
            Оставляете заявку. <br /> Наш менеджер <br />с Вами связывается
          </p>
        </div>

        <div>
          <h1 className="white-h1">2</h1>
          <p className="white-p">
            Оставляете заявку. <br /> Наш менеджер <br />с Вами связывается
          </p>
        </div>

        <div>
          <h1 className="white-h1">3</h1>
          <p className="white-p">
            Оставляете заявку. <br /> Наш менеджер <br />с Вами связывается
          </p>
        </div>

        <div>
          <h1 className="white-h1">4</h1>
          <p className="white-p">
            Оставляете заявку. <br /> Наш менеджер <br />с Вами связывается
          </p>
        </div>

        <div>
          <h1 className="white-h1">5</h1>
          <p className="white-p">
            Оставляете заявку. <br /> Наш менеджер <br />с Вами связывается
          </p>
        </div>
      </div>

      <div className="left-button">
        <button className="заявку-article">Оставить заявку</button>
        <hr className="hrwe" />
        <div className="hers-center">
          <hr className="hrwe2" />
          <hr className="hrwe2" />
          <hr className="hrwe2" />
          <hr className="hrwe2" />
        </div>
      </div>
    </div>
  );
};

export default Article;
